ABOUT
	This is a skin pack made made specifically for the RetroFW firmware, 
	It will work with just about any firmware that uses the "gmenu" interface, though expect some slight visual discrepancies.
	
	Skin made by Fábio Fontes. If you like this, further work from him can be checked at:
	https://www.deviantart.com/fontesmakua
	https://twitter.com/FontesRanter
	https://www.facebook.com/fabiofontesart/

INSTALL
	Just drag the "apps" folder into the partition's root. It should be automatically be selectable when you unmount. If not, restart and that should be it. 
	You might also want to turn "Section Label" off, if such an option is available on your skin settings.

CHANGELOG
	v1.1 (20/April/2019)
		- Standalone release.
		- Revamped the section bar iconography
		- Added multiple color versions
			- Gray (already in v1.0)
			- Red
			- Orange
			- Yellow (already in v1.0)
			- Green
			- Teal
			- Blue
			- Purple
			- Pink
		- Added icon for Beebem
		- Added icon for Mame4All
		- Added icon for Stella
		- Added icon for Cave Story
		- Replaced icon for Streets of Rage Remake

	v1.0 (17/April/2019)
		- Got released as a bundle with RetroFW (Gray and Yellow colors).