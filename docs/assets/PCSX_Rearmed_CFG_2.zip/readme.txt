================================================================
---++++---HYJiNX187's PCSX-Rearmed Config Library v1.1---++++---
================================================================

v1.1 Release Notes -

-Added 25 PSX CFGs (Total 125)
-Update Gmenu2x Entry to support *.cue files and hide *.bin

v1.0 -

-Added 100 PSX CFGs
-Added Gmenu2x Custom Entry
-Added pcsx.dge wrapper script for loading cfg


===Introduction===
This package was created to add PSX support on top of the guide
that RetroGameCorps provided for the Powkiddy v90.

The guide can be found at the following location:
https://retrogamecorps.com/2021/02/01/review-powkiddy-v90/

It is recommended that you follow this guide, including the step
to install the updated pcsx binary.

NOTE: The updated pcsx should show "October 2019" under the
"Credits" submenu inside of pcsx. To make 100% sure you have this
updated version, I am including the link below:

https://retrogamecorps.files.wordpress.com/2021/02/pcsx.zip

YOU WILL NOT ACHIEVE 60FPS WITHOUT THE ABOVE PCSX VERSION!

Though this was designed and tested on the Powkiddy v90, these
configs should work fine on all devices running Miyoo 1.3.3.
(example powkiddy q90 and the first pocketgo)

Your mileage may vary on devices other than the one I have 
targetted with this release.

===Pre-Requisites===
Because I used many different BIOS to create these custom
configs, it is recommended that you provide the following PSX
BIOS. I cannot provide these to you, you will need to locate
them and ensure that they are placed in \emus\pcsx_rearmed\bios
-PSXONPSP660.BIN
-SCPH1001.BIN
-scph5500.bin
-scph5501.bin
-scph5502.bin
-scph7001.bin
-scph7502.bin

The 100 cfg files provided by this package expect NTSC PBP "roms"
to be named the same and reside in /roms/PS1/*.PBP

You will need to source your own PBP files and you should rename 
them to match the names of the cfg files located in 
\emus\pcsx_rearmed\.pcsx\cfg\*.cfg

If your PBP files are not named exactly like their corresponding 
CFG they will not load.

Example:
\roms\PS1\Alien_Resurrection_(USA).PBP
\emus\pcsx_rearmed\.pcsx\cfg\Alien_Resurrection_(USA).cfg

NOTE: The PBPs I used to test were official PBPs provided by PSN 
Servers. PSX ROMs available across the internet are of many
different formats, regions and versions. I cannot help you find
these and your mileage may vary if you use ROMs that are not
official NTSC PBPs of the games supported in this release.

Sharing of BIOS or PBPs is illegal and you should not ask for
help in obtaining these. Officially, you should be purchasing
these games and scraping them off of your devices.

NOTE2: Many members of the community have started to have success 
with BIN/CUE files. I've updated the Gmenu2x entry to allow for 
filtering on both bin and cue files(thanks @rra). One thing we 
have realized is that if your PSX game does not boot under the 
default pcsx.cfg that comes with miyoo, then you likely have an
incompatible game and need to find another copy. 

===Installation===
Unzip the contents of the zip file into the "Main" partition of
you Miyoo 1.3.3 CFW SD Card.



===Additional Information===
This package provides configs for the top 100 games as defined by
the GameFAQs community and was created using the following thread

https://gamefaqs.gamespot.com/boards/916392-playstation/73165050


Both my package and RetroGameCorps Powkiddy v90 Guide are based on
Miyoo CFW 1.3.3 which can be found here:

https://github.com/TriForceX/MiyooCFW


PCSX-Rearmed was original ported by "Sauce" aka "GameBlaBla"
https://github.com/gameblabla/pcsx_rearmed/

The pcsx.dge and accompanying Gmenu2x entry are a work around for
the following known issue:

https://github.com/notaz/pcsx_rearmed/issues/163

The -cfg flag does not allow you to directly pass a custom cfg to
PCSX. My DGE script will copy and overwrite the global pcsx.cfg
file for every game you launch under the Gmenu2x folder. When/if
this bug is resolved, the cfg files should be able to be passed
with a -cfg parameter file, but you will need to use my script
until the bug is resolved.

Note from rra(tester) about bin/cues:
All of the Roms that I used in testing were bin-cue files.  I 
extracted them from my MAME set of PSX CHD files using the CHDMAN 
tool included in MAME.  I made this decision because most of my 
PBP ROMs weren't working and the bin-cue files I found elsewhere 
usually had 1 cue and many bin files for each track that cluttered 
up my rom folder. With the chdman tool extracting from the MAME 
chd's you get one bin and one cue.  Very clean.

The command to extract the bin and cue from a MAME chd is....
chdman extractcd -i filename.chd -o filename.cue -ob filename.bin

===Thank You===
Thanks to my wife for tolerating a tinkerer.

Thanks to Russ @ RetroGameCorps for the constant inspiration!

Thank you to Jutleys and the RGHandhelds Discord Community! 
https://www.rghandhelds.com/

Special thanks to rra for testing this release!

-Sezuko
-npaladin2000
-Hans
-Slystral
-Muffins
-DotMatrixHead
-TriForce
-DVDFan
-thegreatcrippler
-xs4all
-salvacam
-xxcoder
-Sauce
-RetroGameCorps
-npaladin2000
-slaminger
-Christian_Haitian
-rra
-foo
-Death knightx
-STLegend
-


Join us on the rghandhelds.com Discord channel #powkiddy-v90
Don't you dare ask for PBPs or BIOS files!