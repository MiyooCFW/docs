Utility to create cache files from roms for FBA2X (FinalBurnAlpha emulator).


To Generate Cache Files:
1. Unzip FBACache.zip somewhere
2. Copy the ROM set to the 'roms' folder of FBACache
3. If it's a NeoGeo or PGM game, copy also the BIOS set (neogeo.zip or pgm.zip)
4. If it's a clone set, copy also the parent set
5. Open the Command Prompt, and go to the FBACache directory
6. Type and enter 'fbacache.exe -d [romname].zip' (no quotes, and [romname] is the ROM set's filename)
7. Wait until the dumping process completes (make sure no missing files are indicated)
8. Copy only the [romname].fba to the ROMs folder of FBA2X in the SD card

by @HeadOverHeels via https://pyra-handheld.com/boards/resources/fba-cache.1540/